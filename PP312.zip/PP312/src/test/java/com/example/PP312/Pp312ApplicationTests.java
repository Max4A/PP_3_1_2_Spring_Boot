package com.example.PP312;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pp312ApplicationTests {

	@Test
	void contextLoads() {
	}

}
